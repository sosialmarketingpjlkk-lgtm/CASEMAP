# CASEMAP untuk Android

Proyek ini membungkus aplikasi CASEMAP (app/src/main/assets/index.html) dalam WebView. Data tersimpan di perangkat.

## Cara membuat APK
1. Android Studio: File > Open folder ini, tunggu sinkronisasi, lalu Build > Build APK(s). Hasil: app/build/outputs/apk/debug/app-debug.apk
2. Tanpa Android Studio: unggah folder ini ke repositori GitHub. Tab Actions > Build APK > Run workflow, lalu unduh artefak casemap-apk.
3. Baris perintah (JDK 17, Android SDK, Gradle 8.7): gradle assembleDebug

## Memasang di ponsel
Salin APK ke ponsel, buka, dan izinkan pemasangan dari sumber ini. APK debug cukup untuk penggunaan sendiri; untuk Play Store buat build release bertanda tangan (Build > Generate Signed Bundle / APK).

## Catatan
Font Google tidak dimuat saat luring (tampil font sistem). Tombol Cetak tidak berfungsi di WebView; gunakan Salin teks.
